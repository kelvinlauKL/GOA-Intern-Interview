//
//  CustomCell.swift
//  GoA List
//
//  Created by Hana Domingo on 2018-05-13.
//  Copyright © 2018 Hana Domingo. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
