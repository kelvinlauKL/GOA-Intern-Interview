//
//  ImageList.swift
//  A3
//
//  Created by Paul Tang on 2018-05-13.
//  Copyright © 2018 Paul Tang. All rights reserved.
//

import UIKit

var imageList = [UIImage]()
